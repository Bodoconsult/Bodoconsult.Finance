# IO.Swagger.Model.MultiStepAuthenticationCallback
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Hash** | **string** | Hash that was returned previously in a multi-step authentication error. | 
**ChallengeResponse** | **string** | Challenge response. This field should be set only when the previous attempt of import/update the bank connection failed or request a SEPA money transfer failed with HTTP code 510, i.e. the bank sent a challenge for the user for an additional authentication. In this case, this field must contain the response to the bank&#39;s challenge. Note that in the context of finAPI&#39;s web form flow, finAPI will automatically deal with getting the challenge response from the user via the web form. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

