# IO.Swagger.Model.MultiStepAuthenticationChallenge
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Hash** | **string** | Hash for this multi-step authentication flow. Must be passed back to finAPI when continuing the flow. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

