# IO.Swagger.Model.ExecutePasswordChangeParams
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UserId** | **string** | User identifier | 
**Password** | **string** | User&#39;s new password. Minimum length is 6, and maximum length is 36. | 
**PasswordChangeToken** | **string** | Decrypted password change token (the token that you received from the /users/requestPasswordChange service, decrypted with your data decryption key) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

