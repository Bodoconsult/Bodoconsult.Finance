# IO.Swagger.Model.MultiStepAuthenticationCallback
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Hash** | **string** | Hash that was returned in the previous multi-step authentication error. | 
**ChallengeResponse** | **string** | Challenge response. Must be set when the previous multi-step authentication error had status &#39;CHALLENGE_RESPONSE_REQUIRED. | [optional] 
**TwoStepProcedureId** | **string** | The bank-given ID of the two-step-procedure that should be used for authentication. Must be set when the previous multi-step authentication error had status &#39;TWO_STEP_PROCEDURE_REQUIRED. | [optional] 
**RedirectCallback** | **string** | Must be passed when the previous multi-step authentication error had status &#39;REDIRECT_REQUIRED&#39;. The value must consist of the complete query parameter list that was contained in the received redirect from the bank. | [optional] 
**DecoupledCallback** | **bool?** | Must be passed when the previous multi-step authentication error had status &#39;DECOUPLED_AUTH_REQUIRED&#39; or &#39;DECOUPLED_AUTH_IN_PROGRESS&#39;. The field represents the state of the decoupled authentication meaning that when it&#39;s set to &#39;true&#39;, the end-user has completed the authentication process on bank&#39;s side. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

